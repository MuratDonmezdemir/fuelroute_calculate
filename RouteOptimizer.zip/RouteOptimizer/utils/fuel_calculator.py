import csv
from config import VEHICLE_RANGE, VEHICLE_MPG
import numpy as np

class FuelCalculator:
    def __init__(self):
        self.fuel_prices = self._load_fuel_prices()
        self.vehicle_range = VEHICLE_RANGE
        self.vehicle_mpg = VEHICLE_MPG

    def _load_fuel_prices(self):
        """Load fuel prices from CSV file"""
        prices = {}
        try:
            with open('static/fuel_prices.csv', 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    state = row['State']
                    price = float(row['Price'])
                    prices[state] = price
            return prices
        except Exception as e:
            print(f"Error loading fuel prices: {e}")
            return {}

    def calculate_fuel_stops(self, route):
        """Calculate optimal fuel stops based on price and range"""
        total_distance = sum(maneuver['distance'] for maneuver in route)
        num_stops = int(np.ceil(total_distance / self.vehicle_range))

        if num_stops <= 1:
            return []

        # Calculate ideal stop distances
        stop_distances = np.linspace(0, total_distance, num_stops + 1)[1:-1]

        fuel_stops = []
        current_distance = 0

        for stop_distance in stop_distances:
            # Find nearest point in route
            for maneuver in route:
                current_distance += maneuver['distance']
                if current_distance >= stop_distance:
                    # Find nearest cheap gas station
                    nearest_station = self._find_nearest_station(
                        maneuver['startPoint']['lat'],
                        maneuver['startPoint']['lng']
                    )
                    fuel_stops.append(nearest_station)
                    break

        return fuel_stops

    def _find_nearest_station(self, lat, lng):
        """Find the nearest cheap gas station"""
        # For demonstration, return the price from the nearest state
        # In a real implementation, this would use actual gas station data
        state = self._get_state_from_coords(lat, lng)
        price = self.fuel_prices.get(state, 3.50)  # Default price if state not found
        return {
            'lat': lat,
            'lng': lng,
            'price': price
        }

    def _get_state_from_coords(self, lat, lng):
        """Get state name from coordinates (simplified version)"""
        # This is a simplified version. In a real implementation,
        # we would use a proper reverse geocoding service
        # For now, return a random state for demonstration
        import random
        return random.choice(list(self.fuel_prices.keys()))

    def calculate_total_cost(self, distance):
        """Calculate total fuel cost for the trip"""
        gallons_needed = distance / self.vehicle_mpg
        # Use average price across all states
        avg_price = sum(self.fuel_prices.values()) / len(self.fuel_prices) if self.fuel_prices else 3.50
        return round(gallons_needed * avg_price, 2)