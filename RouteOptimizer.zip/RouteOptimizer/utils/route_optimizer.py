import requests
import uuid
import os
from config import OSRM_API_URL, CACHE_TIMEOUT
from functools import lru_cache
import polyline

class RouteOptimizer:
    def __init__(self):
        self.api_url = OSRM_API_URL

    @lru_cache(maxsize=100)
    def get_route(self, start, end):
        """Get route information from OSRM API"""
        # First, geocode the locations using Nominatim
        start_coords = self._geocode_location(start)
        end_coords = self._geocode_location(end)

        if not start_coords or not end_coords:
            return {'error': 'Unable to geocode locations'}

        # Format coordinates for OSRM
        coords = f"{start_coords['lng']},{start_coords['lat']};{end_coords['lng']},{end_coords['lat']}"
        url = f"{self.api_url}/{coords}"

        try:
            response = requests.get(url)
            data = response.json()

            if data.get('code') != 'Ok':
                return {'error': 'Unable to find route'}

            route = data['routes'][0]
            steps = self._parse_route_steps(route)

            return {
                'route': steps,
                'distance': route['distance'] * 0.000621371  # Convert meters to miles
            }

        except Exception as e:
            return {'error': str(e)}

    def _geocode_location(self, location):
        """Geocode location using Nominatim"""
        try:
            url = f"https://nominatim.openstreetmap.org/search"
            params = {
                'q': location,
                'format': 'json',
                'limit': 1,
                'countrycodes': 'us'  # Limit to USA
            }
            headers = {'User-Agent': 'route-planner/1.0'}
            response = requests.get(url, params=params, headers=headers)
            data = response.json()

            if data:
                return {
                    'lat': float(data[0]['lat']),
                    'lng': float(data[0]['lon'])
                }
            return None
        except Exception:
            return None

    def _parse_route_steps(self, route):
        """Parse OSRM route into steps"""
        coords = polyline.decode(route['geometry'])
        steps = []
        total_distance = 0

        for i in range(len(coords)):
            lat, lng = coords[i]
            if i > 0:
                prev_lat, prev_lng = coords[i-1]
                # Calculate rough distance between points
                dist = self._haversine_distance(prev_lat, prev_lng, lat, lng)
                total_distance += dist

            steps.append({
                'startPoint': {'lat': lat, 'lng': lng},
                'distance': total_distance * 0.621371  # Convert km to miles
            })

        return steps

    def _haversine_distance(self, lat1, lon1, lat2, lon2):
        """Calculate the great circle distance between two points"""
        from math import radians, sin, cos, sqrt, atan2

        R = 6371  # Earth's radius in kilometers

        lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1

        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        return R * c

    def generate_map(self, route, fuel_stops):
        """Generate a map with the route and fuel stops"""
        map_id = str(uuid.uuid4())

        # Create route coordinates array for the template
        route_coords = [[point['startPoint']['lat'], point['startPoint']['lng']] for point in route]

        # Create fuel stop markers for the template
        fuel_markers = [{'lat': stop['lat'], 'lng': stop['lng'], 'price': stop['price']} for stop in fuel_stops]

        # Create the map HTML file
        map_html = self._generate_map_html(route_coords, fuel_markers)

        # Save the map
        os.makedirs('static/maps', exist_ok=True)
        with open(f'static/maps/{map_id}.html', 'w') as f:
            f.write(map_html)

        return map_id

    def _generate_map_html(self, route_coords, fuel_markers):
        """Generate the HTML content for the map"""
        markers_js = ','.join([
            f"{{lat: {m['lat']}, lng: {m['lng']}, price: {m['price']}}}"
            for m in fuel_markers
        ])

        route_js = ','.join([f"[{p[0]}, {p[1]}]" for p in route_coords])

        return f"""
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <style>
        #map {{
            height: 100vh;
            width: 100%;
        }}
    </style>
</head>
<body>
    <div id="map"></div>
    <script>
        var map = L.map('map');
        L.tileLayer('https://{{s}}.tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', {{
            attribution: '© OpenStreetMap contributors'
        }}).addTo(map);

        var route = [{route_js}];
        var fuelStops = [{markers_js}];

        // Add route polyline
        var routeLine = L.polyline(route, {{color: 'blue', weight: 3}}).addTo(map);

        // Add fuel stop markers
        fuelStops.forEach(function(stop) {{
            L.marker([stop.lat, stop.lng])
             .bindPopup('Fuel Stop<br>Price: $' + stop.price + '/gal')
             .addTo(map);
        }});

        // Fit map to route bounds
        map.fitBounds(routeLine.getBounds());
    </script>
</body>
</html>
"""