import json
import logging
from flask import Flask, request, jsonify, render_template, send_from_directory
from utils.route_optimizer import RouteOptimizer
from utils.fuel_calculator import FuelCalculator

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)

route_optimizer = RouteOptimizer()
fuel_calculator = FuelCalculator()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/route', methods=['POST'])
def plan_route():
    try:
        data = request.get_json()
        start = data.get('start')
        end = data.get('end')

        if not start or not end:
            return jsonify({'error': 'Start and end locations are required'}), 400

        # Get route details
        route_data = route_optimizer.get_route(start, end)
        if 'error' in route_data:
            return jsonify(route_data), 400

        # Calculate optimal fuel stops
        fuel_stops = fuel_calculator.calculate_fuel_stops(route_data['route'])

        # Generate map
        map_id = route_optimizer.generate_map(route_data['route'], fuel_stops)

        response = {
            'route': route_data['route'],
            'distance': route_data['distance'],
            'fuel_stops': fuel_stops,
            'total_fuel_cost': fuel_calculator.calculate_total_cost(route_data['distance']),
            'map_url': f'/map/{map_id}'
        }

        return jsonify(response)

    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/map/<map_id>')
def show_map(map_id):
    return render_template('map.html', map_id=map_id)

@app.route('/static/maps/<path:filename>')
def serve_map(filename):
    return send_from_directory('static/maps', filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)