import os

# Vehicle configuration
VEHICLE_RANGE = 500  # miles
VEHICLE_MPG = 10    # miles per gallon

# OSRM API endpoint (free and open source)
OSRM_API_URL = "http://router.project-osrm.org/route/v1/driving"

# Cache settings
CACHE_TIMEOUT = 3600  # 1 hour